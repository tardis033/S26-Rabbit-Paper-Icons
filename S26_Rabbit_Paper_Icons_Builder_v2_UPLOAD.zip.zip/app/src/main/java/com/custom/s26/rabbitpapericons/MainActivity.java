package com.custom.s26.rabbitpapericons;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    TextView t=new TextView(this);
    t.setText("S26 Rabbit Paper Icons\n\n20 hand-painted icons\nDesigned for Samsung Theme Park / One UI");
    t.setTextSize(18); t.setGravity(Gravity.CENTER); t.setTextColor(Color.rgb(120,75,40));
    t.setBackgroundColor(Color.rgb(255,248,234)); setContentView(t);
  }
}
