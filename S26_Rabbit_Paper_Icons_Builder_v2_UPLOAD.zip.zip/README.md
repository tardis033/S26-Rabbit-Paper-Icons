# S26 Rabbit Paper Icons

Android icon-pack source project rebuilt for browser/cloud Android builders.

- Application: S26 Rabbit Paper Icons
- Package: com.custom.s26.rabbitpapericons
- Version: 1.0 (1)
- Compile/Target SDK: 36 (Android 16)
- 20 transparent 432x432 PNG icons
- `appfilter.xml` included in `res/xml` and `assets`
- Unknown apps are intentionally not assigned guessed package names.

## Build
Use a cloud Android builder and choose **APK** + **Release**. The project uses Android Gradle Plugin 8.13.2 / Gradle 8.13 and Java 17. AGP 8.13 supports API 36.

## Important
Samsung Theme Park's third-party icon-pack support is not an official Android API. This project exposes standard icon-pack intent filters and appfilter resources, but final recognition remains dependent on the installed Theme Park version.
