package com.tardis.s26rabbit;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;
public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    TextView t = new TextView(this);
    t.setText("S26 Rabbit Paper Icons\n20 custom icons");
    t.setTextSize(20);
    t.setTextColor(Color.DKGRAY);
    t.setGravity(Gravity.CENTER);
    setContentView(t);
  }
}