package com.custom.s26.rabbitpapericons;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView view = new TextView(this);
        view.setBackgroundColor(Color.rgb(231, 235, 236));
        view.setTextColor(Color.rgb(25, 22, 36));
        view.setTextSize(18);
        view.setGravity(Gravity.CENTER);
        view.setText("S26 Rabbit Paper Icons\n20 hand-painted icons\nDesigned for Samsung Theme Park / One UI");
        setContentView(view);
    }
}
