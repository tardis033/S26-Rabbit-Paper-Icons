# S26 Rabbit Paper Icons — updated icon assets

This builder archive is intended to replace the existing
`S26_Rabbit_Paper_Icons_Builder_v2_UPLOAD.zip` in the existing repository.

- Same applicationId: `com.custom.s26.rabbitpapericons`
- 20 PNG icon drawables, 432x432, transparent canvas
- No Chinese text inside the icon artwork
- Existing GitHub Actions workflow remains unchanged
