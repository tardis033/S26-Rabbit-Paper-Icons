S26 Rabbit Paper Icons - icon pack project

Replace the existing S26_Rabbit_Paper_Icons_Builder_v2_UPLOAD.zip in the repository with this archive.
The existing GitHub Actions workflow is expected to unzip this archive into android-project.

20 icon assets:
calendar, calculator, messages, browser, gallery, contacts, phone, wechat,
camera, cokecloud, netease_music, qq, recorder, notes, zhihu, bianleme,
meituan, clock, miaomiaobill, xiaohongshu.

The archive contains no Chinese app-label text; the home-screen labels are controlled by the launcher.
The icon artwork itself is border-free/non-masked and follows the supplied wallpaper's black hand-drawn line style.
